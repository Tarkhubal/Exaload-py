# Button Hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/kathykato/pen/rZRaNe](https://codepen.io/kathykato/pen/rZRaNe).

Pure CSS (SCSS) arrow button hover effect.