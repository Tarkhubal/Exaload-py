# Hack. A digital card game

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/abYNyLq](https://codepen.io/jcoulterdesign/pen/abYNyLq).

Maximum penetration!