# Scrollable pagination, neon theme

A Pen created on CodePen.io. Original URL: [https://codepen.io/pnpicot/pen/PoXpYWp](https://codepen.io/pnpicot/pen/PoXpYWp).

I tried to make this pagination system as easy to use as possible and to make it intuitive.

You can click on the page button, on the left and right button to get to the left-most or right-most page and you can also scroll with your mousewheel inside the container.

All that with a neon theme as bonus with some animations :)